package com.example.Customer;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.Customer.Customer;
import com.example.Customer.CustomerRepository;

@Service
public class ServiceImplementation implements CustomerService {

	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public List<Customer> getAllCustomers() {
		return customerRepository.findAll();
	}

	@Override
	public Customer getCustomerById(int id) {
		Optional<Customer> customer = customerRepository.findById(id);
		return customer.orElse(null);
	}

	@Override
	public Customer addCustomer(Customer customer) {
		return customerRepository.save(customer);
	}

	@Override
	public Customer updateCustomer(int id, Customer customer) {
		if (customerRepository.existsById(id)) {
			customer.setCustomerId(id);
			return customerRepository.save(customer);
		}
		return null;
	}

	@Override
	public void deleteCustomer(int id) {
		customerRepository.deleteById(id);
	}
}
